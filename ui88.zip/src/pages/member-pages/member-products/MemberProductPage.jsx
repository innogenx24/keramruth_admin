import { useState, useEffect } from "react";
import {
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Button,
  Switch,
  Typography,
  TablePagination,
  Box,
} from "@mui/material";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import SearchProducts from "../booking-order/SearchProducts";
import { API_END_POINT_IMG } from "../../../constants/ApiConstant";

const MemberProductPage = () => {
  const navigate = useNavigate();
  const [products, setProducts] = useState([]);
  const [page, setPage] = useState(0); // Pagination state
  const [rowsPerPage, setRowsPerPage] = useState(20); // Rows per page
  const API_END_POINT = import.meta.env.VITE_API_ENDPOINT;
  const imageBaseURL = `${API_END_POINT_IMG}/uploads/`;
  const [searchQuery, setSearchQuery] = useState("");

  // Fetch products from API
  const fetchProducts = async () => {
    const token = localStorage.getItem("token");
    if (!token) {
      alert("Token not found. Please log in.");
      return;
    }

    try {
      const response = await axios.get(
        `${API_END_POINT}/products/user_product`,
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
      // const sortedProducts = response.data.sort((a, b) => b.id - a.id);

      setProducts(response.data);
    } catch (error) {
      console.error("Error fetching products:", error);
    }
  };

  useEffect(() => {
    fetchProducts();
  }, []);

  // Handle page change
  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  // Handle rows per page change
  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0); // Reset to the first page when changing rows per page
  };

  const sortedProducts = [...products].sort((a, b) => b.id - a.id); // Sort by ID in descending order

  const columns = [
    { id: 'no', label: 'No.' },
    { id: 'image', label: 'Product Image' },
    { id: 'name', label: 'Product Name' },
    { id: 'stock_quantity', label: 'Stock Quantity' },
    { id: 'category_name', label: 'Category Name' },
    { id: 'productVolume', label: 'Product Volume' },
    { id: 'price', label: 'MRP' },
  ];


  const filteredProducts = products.filter((product) =>
    product.name.toLowerCase().includes(searchQuery.toLowerCase())
  );


  const renderPagination = (page, setPage, totalRows) => (
    <div style={{ display: "flex", justifyContent: "right", alignItems: "center", gap: "15px" }}>
      <Button
        onClick={() => setPage(page - 1)}
        disabled={page === 0}
        variant="outlined"
      >
        Previous
      </Button>
      <Typography variant="body1" style={{ minWidth: "60px", textAlign: "center" }}>
        Page {page + 1} of {Math.ceil(totalRows / rowsPerPage)}
      </Typography>
      <Button
        onClick={() => setPage(page + 1)}
        disabled={page >= Math.ceil(totalRows / rowsPerPage) - 1}
        variant="outlined"
      >
        Next
      </Button>
    </div>
  );

  return (
    <div>
      <Typography variant="h6" sx={{ marginBottom: "20px", color: "#989FA9" }}>
        All Products
      </Typography>
      <Box sx={{ width: "100%", marginBottom: 2 }}>
        <SearchProducts value={searchQuery} onSearchChange={setSearchQuery} />
      </Box>
      <div
        style={{
          display: "flex",
          justifyContent: "flex-end",
          marginBottom: "20px",
        }}
      >

      </div>
      <TableContainer component={Paper}>
        <Table aria-label="product table">
          <TableHead sx={{ position: "sticky", top: 0, zIndex: 1, backgroundColor: "#DCDCDC" }}>
            <TableRow>
              {columns.map((column) => (
                <TableCell key={column.id}>{column.label}</TableCell>
              ))}
            </TableRow>
          </TableHead>
          <TableBody>
            {filteredProducts
              .slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
              .map((product, index) => (
                <TableRow key={product.id}>
                  <TableCell>{page * rowsPerPage + index + 1}</TableCell>
                  <TableCell>
                    {product.image ? (
                      <img
                        src={`${imageBaseURL}${product.image}`}
                        style={{
                          width: "100px",
                          height: "auto",
                          objectFit: "contain",
                          border: "1px solid #ccc",
                          boxShadow: "2px 2px 5px rgba(0, 0, 0, 0.2)",
                          borderRadius: "10px",
                        }}
                      />
                    ) : (
                      <span>No Image Available</span>
                    )}
                  </TableCell>

                  <TableCell>{product.name}</TableCell>
                  <TableCell>
                    {new Intl.NumberFormat('en-IN').format(product.stock_quantity)}
                  </TableCell>

                  <TableCell>{product.category_name}</TableCell>
                  <TableCell>{product.productVolume}{product.quantity_type}</TableCell>

                  <TableCell>
                    {product.super1 && product.super1 !== '0.00'
                      ? `Rs. ${new Intl.NumberFormat('en-IN', { maximumFractionDigits: 2 }).format(parseFloat(product.super1))}`
                      : `Rs. ${new Intl.NumberFormat('en-IN', { maximumFractionDigits: 2 }).format(parseFloat(product.originalPrice))}`
                    }
                  </TableCell>

                </TableRow>
              ))}
          </TableBody>
        </Table>
      </TableContainer>
      <div style={{ marginTop: "10px" }}>
        {renderPagination(page, setPage, filteredProducts.length)}
      </div>

    </div>
  );
};

export default MemberProductPage;
